
from utils import parse_log_line

def process_chunk(lines):
    result = {}
    for line in lines:
        log_type = parse_log_line(line)
        if log_type:
            result[log_type] = result.get(log_type, 0) + 1
    return result
