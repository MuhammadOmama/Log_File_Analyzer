

import tkinter as tk
from tkinter import filedialog, ttk, scrolledtext, messagebox
from collections import Counter
import re
import os
import threading
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import google.generativeai as genai
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.style import WD_STYLE_TYPE
from PIL import Image, ImageTk 


class LogAnalyzerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Parallel & Distributed Log File Analyzer")
        self.root.geometry("1200x700")
        self.file_path = None
        self.graph_data = {}
        self.graph_titles = []
        self.current_graph_index = 0

        self.setup_styles()
        self.setup_widgets()
        self.cancel_requested = False

    def setup_styles(self):
        # Configure a modern theme
        self.style = ttk.Style()
        # Try different themes if available, 'clam' is generally good across platforms
        available_themes = self.style.theme_names()
        if 'clam' in available_themes:
            self.style.theme_use('clam')
        elif 'alt' in available_themes:
            self.style.theme_use('alt')
        else:
            self.style.theme_use('default') # Fallback

        # Define a color palette
        self.primary_color = "#4CAF50"  # Green
        self.secondary_color = "#2196F3" # Blue
        self.accent_color = "#FFC107"   # Amber
        self.bg_color = "#ECEFF1"      # Light Grey
        self.text_color = "#263238"     # Dark Grey
        self.error_color = "#f44336"    # Red

        self.style.configure('.', background=self.bg_color, foreground=self.text_color, font=('Arial', 10))
        self.style.configure('TFrame', background=self.bg_color)
        self.style.configure('TLabel', background=self.bg_color, foreground=self.text_color)
        self.style.configure('TButton',
                             background=self.primary_color,
                             foreground='white',
                             font=('Arial', 10, 'bold'),
                             padding=5)
        self.style.map('TButton',
                       background=[('active', '#5cb85c'), ('disabled', '#cccccc')],
                       foreground=[('disabled', '#666666')])

        self.style.configure('TProgressbar', background=self.secondary_color, troughcolor='#CFD8DC')
        self.style.configure('TLabelFrame', background=self.bg_color, foreground=self.text_color)
        self.style.configure('TLabelframe.Label', font=('Arial', 12, 'bold'), foreground=self.secondary_color) # Title of LabelFrame

        # ScrolledText specific styling (Tkinter widget, so direct config)
        self.root.option_add("*ScrolledText*background", "white")
        self.root.option_add("*ScrolledText*foreground", self.text_color)
        self.root.option_add("*ScrolledText*font", "Times New Roman 11")
        self.root.option_add("*ScrolledText*border", "1")
        self.root.option_add("*ScrolledText*relief", "flat")


    def setup_widgets(self):
        # Main frame for padding and background
        self.main_frame = ttk.Frame(self.root, padding="15 15 15 15")
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        # Configure grid weights for responsiveness
        self.main_frame.grid_rowconfigure(2, weight=1) # Row for main content
        self.main_frame.grid_columnconfigure(1, weight=1) # Column for content area

        try:
            logo_image = Image.open("logo3 (2).png")  # Use your logo file name here
            logo_image = logo_image.resize((349, 133), Image.Resampling.LANCZOS)
            # logo_image = logo_image.resize((48, 48), Image.ANTIALIAS)  # Resize as needed
            self.logo_photo = ImageTk.PhotoImage(logo_image)
        except Exception as e:
            print(f"Could not load logo image: {e}")
            self.logo_photo = None

        # Frame for logo and title
        self.title_frame = ttk.Frame(self.main_frame)
        self.title_frame.grid(row=0, column=0, columnspan=3, pady=0)

        # Logo label (if image loaded)
        if self.logo_photo:
            self.logo_label = tk.Label(self.title_frame, image=self.logo_photo, bg=self.bg_color, borderwidth=0, highlightthickness=0)
            self.logo_label.pack(side=tk.TOP, anchor="center", pady=0)  # Set pady=0 to remove extra space
           




        # Control Frame (File selection, upload progress, action buttons)
        self.control_frame = ttk.LabelFrame(self.main_frame, text="File & Analysis Control", padding="10 10 10 10")
        self.control_frame.grid(row=1, column=0, columnspan=3, pady=10, sticky="ew")
        self.control_frame.grid_columnconfigure(1, weight=1) # Make file label expandable

        self.browse_button = ttk.Button(self.control_frame, text="Choose Log File", command=self.browse_file)
        self.browse_button.grid(row=0, column=0, padx=5, pady=5)

        self.file_label = ttk.Label(self.control_frame, text="No file selected", font=("Arial", 10, 'italic'))
        self.file_label.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        self.upload_progress = ttk.Progressbar(self.control_frame, orient='horizontal', mode='determinate', length=300)
        self.upload_progress.grid(row=1, column=0, columnspan=2, padx=5, pady=5, sticky="ew")
        self.upload_progress.grid_forget() # Initially hidden

        # Analysis action buttons
        self.action_buttons_frame = ttk.Frame(self.control_frame)
        self.action_buttons_frame.grid(row=2, column=0, columnspan=2, pady=5)

        self.analyze_button = ttk.Button(self.action_buttons_frame, text="Analyze Log", command=self.start_analysis, state=tk.DISABLED)
        self.analyze_button.pack(side=tk.LEFT, padx=10)

        self.cancel_button = ttk.Button(self.action_buttons_frame, text="Reset", command=self.cancel, state=tk.DISABLED)
        self.cancel_button.pack(side=tk.LEFT, padx=10)

        self.export_button = ttk.Button(self.action_buttons_frame, text="Export AI Report", command=self.export_suggestions_to_word, state=tk.DISABLED)
        self.export_button.pack(side=tk.LEFT, padx=10)

        self.analyze_progress = ttk.Progressbar(self.control_frame, orient='horizontal', mode='determinate', length=400)
        self.analyze_progress.grid(row=3, column=0, columnspan=2, padx=5, pady=5, sticky="ew")
        self.analyze_progress.grid_forget() # Initially hidden


        # Main content area
        self.main_content_frame = ttk.Frame(self.main_frame)
        self.main_content_frame.grid(row=2, column=0, columnspan=3, sticky="nsew", pady=10)
        self.main_content_frame.grid_columnconfigure(1, weight=1) # Content area (right) expands
        self.main_content_frame.grid_rowconfigure(0, weight=1) # Entire main content area expands


        # Navigation panel (left)
        self.nav_panel = ttk.LabelFrame(self.main_content_frame, text="Navigation", padding="10 10 10 10")
        self.nav_panel.grid(row=0, column=0, sticky="ns", padx=10, pady=5)

        self.textual_button = ttk.Button(self.nav_panel, text="Textual Analysis", command=self.show_textual)
        self.textual_button.pack(pady=10, fill=tk.X)

        self.graphical_button = ttk.Button(self.nav_panel, text="Graphical Analysis", command=self.show_graphical)
        self.graphical_button.pack(pady=10, fill=tk.X)


        # Content display area (right)
        self.content_area = ttk.Frame(self.main_content_frame)
        self.content_area.grid(row=0, column=1, sticky="nsew", padx=10, pady=5)
        self.content_area.grid_columnconfigure(0, weight=1) # Textual section
        self.content_area.grid_rowconfigure(0, weight=1) # For proper expansion

        # Textual section
        self.text_section = ttk.LabelFrame(self.content_area, text="Textual Analysis & AI Suggestions", padding="10 10 10 10")
        self.text_section.grid(row=0, column=0, sticky="nsew") # Use grid here as it's the only one in content_area initially
        self.text_section.grid_columnconfigure(0, weight=1) # Output box expands
        self.text_section.grid_columnconfigure(1, weight=1) # Suggestion box expands
        self.text_section.grid_rowconfigure(0, weight=1)

        # Textual Analysis on the left
        self.output_box = scrolledtext.ScrolledText(
            self.text_section,
            wrap=tk.WORD,
            font=("Consolas", 10), # A monospace font is often good for log output
            fg=self.text_color,
            relief=tk.FLAT,
            bd=1
        )
        self.output_box.grid(row=0, column=0, sticky="nsew", pady=5, padx=(0, 5))
        self.output_box.insert(tk.END, "Log analysis results will appear here...")
        self.output_box.config(state=tk.DISABLED)

        # AI Suggestions on the right
        self.suggestion_box = scrolledtext.ScrolledText(
            self.text_section,
            wrap=tk.WORD,
            fg=self.secondary_color, # Blue for suggestions
            font=("Times New Roman", 11),
            relief=tk.FLAT,
            bd=1
        )
        self.suggestion_box.tag_config('title', font=("Arial", 16, "bold"), foreground="#0056b3")
        self.suggestion_box.tag_config('heading1', font=("Arial", 14, "bold"), foreground="#007bff")
        self.suggestion_box.tag_config('heading2', font=("Arial", 12, "bold"), foreground="#28a745")
        self.suggestion_box.tag_config('normal', font=("Arial", 11), foreground="#333333")
        self.suggestion_box.tag_config('bullet', font=("Arial", 11), foreground="#333333", lmargin1=20, lmargin2=40)
        self.suggestion_box.grid(row=0, column=1, sticky="nsew", padx=(0, 0), pady=5)
        self.suggestion_box.insert(tk.END, "AI Suggestions will appear here after analysis.")
        self.suggestion_box.config(state=tk.DISABLED)

        # Graphical section
        self.graph_section = ttk.LabelFrame(self.content_area, text="Graphical Analysis", padding="10 10 10 10")
        # Do NOT grid it here, it will be gridded when show_graphical is called
        self.graph_section.grid_columnconfigure(0, weight=1) # Graph canvas expands
        self.graph_section.grid_rowconfigure(0, weight=1) # Graph canvas expands

        self.graph_canvas = None
        self.graph_nav = ttk.Frame(self.graph_section)
        self.graph_nav.grid(row=1, column=0, pady=5) # Placed inside graph_section

        self.prev_button = ttk.Button(self.graph_nav, text="← Previous Graph", command=self.prev_graph)
        self.prev_button.pack(side=tk.LEFT, padx=5)
        self.next_button = ttk.Button(self.graph_nav, text="Next Graph →", command=self.next_graph)
        self.next_button.pack(side=tk.LEFT, padx=5)

        self.show_textual() # Start with textual analysis view


    def browse_file(self):
        file = filedialog.askopenfilename(filetypes=[("Log Files", "*.log *.txt")])
        if file:
            self.file_path = file
            self.file_label.config(text=f"Selected: {os.path.basename(file)}")
            self.browse_button["state"] = tk.DISABLED
            self.upload_progress.grid(row=1, column=0, columnspan=2, padx=5, pady=5, sticky="ew") # Show progress bar
            self.upload_progress["value"] = 0
            self.cancel_button["state"] = tk.NORMAL # Enable cancel during upload
            self.analyze_button["state"] = tk.DISABLED # Disable analyze until upload complete
            self.export_button.config(state=tk.DISABLED)

            # Clear previous results when new file is selected
            self.output_box.config(state=tk.NORMAL)
            self.output_box.delete("1.0", tk.END)
            self.output_box.insert(tk.END, "Log analysis results will appear here...")
            self.output_box.config(state=tk.DISABLED)
            self.suggestion_box.config(state=tk.NORMAL)
            self.suggestion_box.delete("1.0", tk.END)
            self.suggestion_box.insert(tk.END, "AI Suggestions will appear here after analysis.")
            self.suggestion_box.config(state=tk.DISABLED)
            if self.graph_canvas:
                self.graph_canvas.get_tk_widget().destroy()
            self.graph_data.clear()
            self.graph_titles.clear()
            self.current_graph_index = 0
            self.show_textual() # Ensure textual view is active when a new file is chosen

            threading.Thread(target=self.simulate_upload).start()

    def simulate_upload(self):
        self.cancel_requested = False
        try:
            file_size = os.path.getsize(self.file_path)
            loaded = 0
            chunk_size = 1024 * 100  # 100 KB per read

            with open(self.file_path, 'rb') as f:
                while True:
                    if self.cancel_requested:
                        self.upload_progress["value"] = 0
                        self.upload_progress.grid_forget()
                        self.reset_gui_after_cancel()
                        return
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    loaded += len(chunk)
                    percent = int((loaded / file_size) * 100)
                    self.upload_progress["value"] = percent
                    self.root.update_idletasks()
                    self.root.after(1)

            self.upload_progress["value"] = 100
            self.upload_progress.grid_forget()
            self.cancel_button["state"] = tk.NORMAL
            self.analyze_button["state"] = tk.NORMAL

        except Exception as e:
            messagebox.showerror("File Upload Error", f"Failed to load file: {e}")
            self.reset_gui_after_cancel()


    def cancel(self):
        self.cancel_requested = True
        self.reset_gui_after_cancel()


    def reset_gui_after_cancel(self):
        # Stop any ongoing progress
        self.upload_progress["value"] = 0
        self.upload_progress.grid_forget()
        self.analyze_progress["value"] = 0
        self.analyze_progress.grid_forget()

        # Clear displayed data
        self.output_box.config(state=tk.NORMAL)
        self.output_box.delete("1.0", tk.END)
        self.output_box.insert(tk.END, "Log analysis results will appear here...")
        self.output_box.config(state=tk.DISABLED)

        if self.graph_canvas:
            self.graph_canvas.get_tk_widget().destroy()
            self.graph_canvas = None # Reset canvas
        self.graph_data.clear()
        self.graph_titles.clear()
        self.current_graph_index = 0

        self.suggestion_box.config(state=tk.NORMAL)
        self.suggestion_box.delete("1.0", tk.END)
        self.suggestion_box.insert(tk.END, "AI Suggestions will appear here after analysis.")
        self.suggestion_box.config(state=tk.DISABLED)

        # Re-enable/disable buttons
        self.cancel_button["state"] = tk.DISABLED
        self.analyze_button["state"] = tk.DISABLED
        self.browse_button["state"] = tk.NORMAL
        self.export_button.config(state=tk.DISABLED)
        self.file_label.config(text="No file selected")
        self.file_path = None # Clear file path

    def start_analysis(self):
        if not self.file_path:
            messagebox.showwarning("No File", "Please choose a log file first.")
            return

        self.analyze_button["state"] = tk.DISABLED
        self.cancel_button["state"] = tk.DISABLED # Disable cancel during analysis simulation
        self.export_button.config(state=tk.DISABLED)
        self.analyze_progress.grid(row=3, column=0, columnspan=2, padx=5, pady=5, sticky="ew")
        self.analyze_progress["value"] = 0
        threading.Thread(target=self.simulate_analysis).start()

    def simulate_analysis(self):
        for i in range(101):
            if self.cancel_requested: # Allow cancellation during simulation
                self.analyze_progress["value"] = 0
                self.analyze_progress.grid_forget()
                self.reset_gui_after_cancel()
                return
            self.analyze_progress["value"] = i
            self.root.update_idletasks()
            self.root.after(10) # Simulate work

        self.analyze_progress.grid_forget()
        self.analyze_log()
        self.analyze_button["state"] = tk.NORMAL
        self.cancel_button["state"] = tk.NORMAL # Re-enable cancel button after analysis completes
        self.export_button.config(state=tk.NORMAL)


    def analyze_log(self):
        try:
            with open(self.file_path, 'r', encoding='utf-8', errors='ignore') as f: # Add encoding and error handling
                lines = f.readlines()
        except Exception as e:
            self.output_box.config(state=tk.NORMAL)
            self.output_box.delete("1.0", tk.END)
            self.output_box.insert(tk.END, f"❌ Error reading file:\n{e}\n\nPlease ensure the file is accessible and readable.")
            self.output_box.config(state=tk.DISABLED)
            # Fallback for suggestions even if file read fails (though less meaningful)
            self.show_ai_suggestions("## File Reading Error\n\nCould not read the log file. Please check file permissions or file integrity. AI suggestions cannot be generated without log data.")
            return

        error_count = sum(1 for line in lines if "error" in line.lower())
        warning_count = sum(1 for line in lines if "warning" in line.lower())
        ip_addresses = re.findall(r'[0-9]+(?:\.[0-9]+){3}', '\n'.join(lines))
        ip_counter = Counter(ip_addresses)

        method_counter = Counter()
        url_counter = Counter()
        status_code_counter = Counter()
        hour_counter = Counter()

        for line in lines:
            # Improved regex to handle various log formats, focusing on common Apache/Nginx patterns
            # Example: 127.0.0.1 - - [27/May/2025:10:30:00 +0000] "GET /index.html HTTP/1.1" 200 1234
            match = re.search(r'"(\w+)\s+([^\s]+)\s+HTTP/[\d.]+" (\d{3})', line)
            if match:
                method, url, status = match.groups()
                method_counter[method] += 1
                url_counter[url] += 1
                status_code_counter[status] += 1

            # Time extraction
            time_match = re.search(r'\[(?:\d{1,2}/\w+/\d{4}):(\d{2}):', line) # Matches [DD/Mon/YYYY:HH:MM:SS
            if time_match:
                hour = time_match.group(1)
                hour_counter[hour] += 1
            # If no time match, try to extract from ISO-like timestamp (e.g., 2023-01-01T10:30:00)
            else:
                iso_time_match = re.search(r'T(\d{2}):', line)
                if iso_time_match:
                    hour = iso_time_match.group(1)
                    hour_counter[hour] += 1

        result = (
            f"📄 Total Lines: {len(lines)}\n"
            f"❗ Error Lines: {error_count}\n"
            f"⚠️ Warning Lines: {warning_count}\n\n"
            f"🌐 Top IPs (up to 5):\n"
        )
        if ip_counter:
            for ip, count in ip_counter.most_common(5):
                result += f"  {ip} - {count} times\n"
        else:
            result += "  No IP addresses found.\n"


        result += "\n🔁 HTTP Methods:\n"
        if method_counter:
            for method, count in method_counter.items():
                result += f"  {method}: {count}\n"
        else:
            result += "  No HTTP methods found.\n"

        result += "\n🌍 Top Requested URLs (up to 5):\n"
        if url_counter:
            for url, count in url_counter.most_common(5):
                result += f"  {url} - {count} times\n"
        else:
            result += "  No URLs found.\n"

        result += "\n📊 Status Codes:\n"
        if status_code_counter:
            for status, count in status_code_counter.items():
                result += f"  {status}: {count}\n"
        else:
            result += "  No status codes found.\n"

        result += "\n🕒 Requests Per Hour (00-23):\n"
        if hour_counter:
            # Ensure all 24 hours are present, even if count is 0, for consistent graphing
            all_hours_data = {f"{h:02d}": hour_counter.get(f"{h:02d}", 0) for h in range(24)}
            for hour in sorted(all_hours_data.keys()):
                result += f"  {hour}:00 - {all_hours_data[hour]} requests\n"
        else:
            result += "  No hourly request data found.\n"


        self.output_box.config(state=tk.NORMAL)
        self.output_box.delete("1.0", tk.END)
        self.output_box.insert(tk.END, result)
        self.output_box.config(state=tk.DISABLED)

        # Show "Generating..." message for AI
        self.suggestion_box.config(state=tk.NORMAL)
        self.suggestion_box.delete("1.0", tk.END)
        self.suggestion_box.insert(tk.END, "Generating AI suggestions...")
        self.suggestion_box.config(state=tk.DISABLED)

        def fetch_ai():
            try:
                suggestions = self.get_ai_suggestions(result)
            except Exception as e:
                suggestions = f"❌ AI suggestion error: {e}"
            self.root.after(0, lambda: self.show_ai_suggestions(suggestions)) # Update GUI on main thread


        threading.Thread(target=fetch_ai).start()

        # Prepare graph data
        self.graph_data = {
            "Requests Per Hour": {f"{h:02d}": hour_counter.get(f"{h:02d}", 0) for h in range(24)},
            "Top Requested URLs": dict(url_counter.most_common(5)),
            "HTTP Methods": dict(method_counter),
            "Status Codes": dict(status_code_counter),
            "Top IPs": dict(ip_counter.most_common(5))
        }
        self.graph_titles = list(self.graph_data.keys())
        self.current_graph_index = 0
        self.show_graph() # Display first graph

    def show_textual(self):
        # Hide graphical section, show textual section
        self.graph_section.grid_forget()
        self.text_section.grid(row=0, column=0, sticky="nsew")
        self.textual_button.config(state=tk.DISABLED)
        self.graphical_button.config(state=tk.NORMAL)

    def show_graphical(self):
        # Hide textual section, show graphical section
        self.text_section.grid_forget()
        self.graph_section.grid(row=0, column=0, sticky="nsew")
        self.graphical_button.config(state=tk.DISABLED)
        self.textual_button.config(state=tk.NORMAL)
        self.show_graph() # Ensure graph is displayed when switching

    def show_graph(self):
        if not self.graph_data:
            if self.graph_canvas:
                self.graph_canvas.get_tk_widget().destroy()
                self.graph_canvas = None
            fig, ax = plt.subplots(figsize=(8, 5))
            ax.text(0.5, 0.5, "No data available for graphical analysis.\nPlease analyze a log file first.",
                    horizontalalignment='center', verticalalignment='center', transform=ax.transAxes,
                    fontsize=12, color='gray')
            ax.axis('off') # Hide axes for text display
            fig.tight_layout()
            self.graph_canvas = FigureCanvasTkAgg(fig, master=self.graph_section)
            self.graph_canvas.draw()
            self.graph_canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
            self.prev_button.config(state=tk.DISABLED)
            self.next_button.config(state=tk.DISABLED)
            return

        # Enable/disable navigation buttons based on current index
        self.prev_button.config(state=tk.NORMAL if self.current_graph_index > 0 else tk.DISABLED)
        self.next_button.config(state=tk.NORMAL if self.current_graph_index < len(self.graph_titles) - 1 else tk.DISABLED)


        if self.graph_canvas:
            self.graph_canvas.get_tk_widget().destroy()

        title = self.graph_titles[self.current_graph_index]
        data = self.graph_data[title]

        fig, ax = plt.subplots(figsize=(8, 5))

        if title == "Requests Per Hour":
            # Convert string keys to int for proper sorting on x-axis
            x_labels = sorted(data.keys(), key=int)
            y_values = [data[k] for k in x_labels]
            ax.plot(x_labels, y_values, marker='o', linestyle='-', color=self.primary_color)
            ax.set_xlabel("Hour of Day")
            ax.set_ylabel("Number of Requests")
            ax.set_xticks(x_labels) # Ensure all hours are shown
            ax.set_xticklabels([f"{h}:00" for h in x_labels], rotation=45, ha="right")
            ax.grid(True, linestyle='--', alpha=0.7)
        else:
            if not data: # Handle empty data for other plots
                ax.text(0.5, 0.5, f"No data for '{title}' graph.",
                        horizontalalignment='center', verticalalignment='center', transform=ax.transAxes,
                        fontsize=12, color='gray')
                ax.axis('off')
            else:
                bars = ax.bar(data.keys(), data.values(), color=self.primary_color)
                ax.set_ylabel("Count")
                ax.set_xticks(range(len(data)))
                ax.set_xticklabels(data.keys(), rotation=45, ha="right")
                # Add value labels on top of bars
                for bar in bars:
                    yval = bar.get_height()
                    ax.text(bar.get_x() + bar.get_width()/2, yval + 0.5, int(yval), ha='center', va='bottom', fontsize=8)


        ax.set_title(title, color=self.secondary_color, fontsize=14, fontweight='bold')
        fig.tight_layout()

        self.graph_canvas = FigureCanvasTkAgg(fig, master=self.graph_section)
        self.graph_canvas.draw()
        self.graph_canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew", padx=5, pady=5) # Place canvas in grid

    def prev_graph(self):
        if self.current_graph_index > 0:
            self.current_graph_index -= 1
            self.show_graph()

    def next_graph(self):
        if self.current_graph_index < len(self.graph_titles) - 1:
            self.current_graph_index += 1
            self.show_graph()

    def generate_suggestions(self, error_count, warning_count, ip_counter, method_counter, status_code_counter):
        # This function is now specifically for the fallback, and it should take structured data
        # rather than trying to parse the 'result' string.
        # However, to keep existing logic working with minimal change, I'll adapt it.
        # It's better to pass the direct counters to this fallback.
        suggestions = []
        if error_count > 0:
            suggestions.append(f"High number of errors detected ({error_count}). Check error logs for root causes.")
        if warning_count > 0:
            suggestions.append(f"Warnings present ({warning_count}). Review warnings for potential issues.")
        
        if ip_counter and max(ip_counter.values()) > 100: # Example threshold
            top_ip, count = ip_counter.most_common(1)[0]
            suggestions.append(f"IP {top_ip} made {count} requests. Possible DDoS or misconfigured client.")
        
        if "POST" in method_counter and method_counter["POST"] > method_counter.get("GET", 0) * 2: # Example threshold
            suggestions.append("Significantly more POST requests than GET. Investigate for unusual API usage or data submission patterns.")
        
        if "500" in status_code_counter and status_code_counter["500"] > 0:
            suggestions.append(f"HTTP 500 errors found ({status_code_counter['500']}). These indicate server-side issues and require immediate investigation.")
        if "404" in status_code_counter and status_code_counter["404"] > 50: # Example threshold for 404s
            suggestions.append(f"High number of HTTP 404 (Not Found) errors ({status_code_counter['404']}). Check for broken links, missing resources, or suspicious scanning activity.")

        if not suggestions:
            suggestions.append("No major issues detected based on basic metrics. System appears healthy.")
        return "\n".join(suggestions)


    def get_ai_suggestions(self, analysis_summary):
        """Fetches AI suggestions using the Gemini API or provides a fallback."""
        api_key = os.getenv("GEMINI_API_KEY")

        if not api_key:
            print("GEMINI_API_KEY environment variable not set. Using fallback suggestions.")
            # Pass the extracted counts to the generate_suggestions_fallback
            # This requires parsing the analysis_summary to get counts
            error_count = int(re.search(r'❗ Error Lines: (\d+)', analysis_summary).group(1)) if re.search(r'❗ Error Lines: (\d+)', analysis_summary) else 0
            warning_count = int(re.search(r'⚠️ Warning Lines: (\d+)', analysis_summary).group(1)) if re.search(r'⚠️ Warning Lines: (\d+)', analysis_summary) else 0

            # Re-creating counters from the summary string is less ideal but necessary for fallback
            # when the direct counters aren't available to this function.
            # A better approach would be to pass the raw counters from analyze_log directly.
            # For simplicity, let's use the self.graph_data which already contains the counters.
            ip_counter_fallback = self.graph_data.get("Top IPs", {})
            method_counter_fallback = self.graph_data.get("HTTP Methods", {})
            status_code_counter_fallback = self.graph_data.get("Status Codes", {})


            return (
                "# AI Log Analysis Report\n\n"
                "## Status: AI Integration Notice\n\n"
                "The Gemini AI service is currently unavailable. This is likely because the "
                "GEMINI_API_KEY environment variable has not been set, or there was an "
                "issue connecting to the Google AI API.\n\n"
                "### To Enable AI Suggestions:\n"
                "- Obtain a Gemini API key from [Google AI Studio](https://aistudio.google.com/).\n"
                "- Set it as an environment variable named `GEMINI_API_KEY` in your system.\n"
                "  *(Example for Linux/macOS: `export GEMINI_API_KEY='your_api_key_here'`)*\n"
                "  *(Example for Windows (CMD): `setx GEMINI_API_KEY \"your_api_key_here\"`)*\n\n"
                "--- \n\n" # Separator for fallback suggestions
                "### Auto-Generated Basic Suggestions (Fallback):\n"
                f"{self.generate_suggestions_fallback(analysis_summary)}\n\n"
                "*(Please note: These are basic insights. Full AI suggestions offer more comprehensive advice.)*"
            )

        genai.configure(api_key=api_key)

        prompt = (
            "You are an expert log analyst. Given the following log analysis summary, "
            "generate a formal, structured report with actionable suggestions for the user to improve their system or investigate issues. "
            "The report should have a clear title, a brief executive summary, and numbered sections for detailed recommendations. "
            "Use standard markdown formatting for headings (# for title, ## for main sections, ### for sub-sections) and bullet points (- or * for list items). "
            "Ensure there is a blank line between paragraphs and list items for proper formatting. "
            "Conclude with a professional closing statement. If no major issues, provide positive reinforcement.\n\n"
            f"Log Analysis Summary:\n\n{analysis_summary}\n\n"
            "Generate the report:"
        )
        try:
            model = genai.GenerativeModel("gemini-1.5-flash") # Using a faster model for chat/summarization
            response = model.generate_content(prompt)
            return response.text.strip()
        except Exception as e:
            print(f"Error calling Gemini API: {e}")
            return (
                "# AI Log Analysis Report\n\n"
                "## Status: AI Generation Error\n\n"
                f"An error occurred while generating AI suggestions: {e}\n\n"
                "### Troubleshooting Steps:\n"
                "- Ensure you have a stable internet connection.\n"
                "- Verify your GEMINI_API_KEY is correct and active.\n"
                "- The model might be overloaded; try again in a moment.\n"
                "- The prompt or log summary might be too long/complex; try a smaller log file.\n\n"
                "--- \n\n" # Separator for fallback suggestions
                "### Auto-Generated Basic Suggestions (Fallback):\n"
                f"{self.generate_suggestions_fallback(analysis_summary)}\n\n"
                "*(Please note: These are basic insights. Full AI suggestions offer more comprehensive advice.)*"
            )

    def generate_suggestions_fallback(self, analysis_summary):
        """Generates basic suggestions based on parsed log summary if AI is unavailable."""
        suggestions = []

        error_match = re.search(r'❗ Error Lines: (\d+)', analysis_summary)
        warning_match = re.search(r'⚠️ Warning Lines: (\d+)', analysis_summary)

        error_count = int(error_match.group(1)) if error_match else 0
        warning_count = int(warning_match.group(1)) if warning_match else 0

        suggestions.append("## Key Observations & Initial Recommendations\n")

        if error_count > 0:
            suggestions.append(f"- **High Error Rate ({error_count} lines):** This is a critical concern. Prioritize investigating the specific error messages to identify root causes such as application bugs, misconfigurations, or service failures. Check application logs and system resource utilization around the timestamps of these errors.")
        if warning_count > 0:
            suggestions.append(f"- **Warnings Present ({warning_count} lines):** While not critical, warnings ({warning_count} instances) often precede errors or indicate suboptimal performance. Review these warnings to address potential issues proactively before they impact stability.")

        # Extract top IPs
        ip_section = re.search(r'🌐 Top IPs:\n(.*?)(?=\n\n|\Z)', analysis_summary, re.DOTALL) # Added \Z for end of string
        if ip_section:
            ip_lines = [line for line in ip_section.group(1).strip().split('\n') if line.strip() != "No IP addresses found."]
            for line in ip_lines:
                ip_match = re.match(r'  (\d+\.\d+\.\d+\.\d+) - (\d+) times', line)
                if ip_match:
                    ip, count = ip_match.groups()
                    count = int(count)
                    if count > 50: # Adjust threshold as appropriate
                        suggestions.append(f"- **Unusual Traffic Source ({ip}):** This IP made {count} requests. If this is unexpected, investigate its origin. It could indicate legitimate high traffic, a misconfigured client, or a security concern like a bot or brute-force attempt. Consider implementing rate limiting or WAF rules.")

        # Extract status codes
        status_section = re.search(r'📊 Status Codes:\n(.*?)(?=\n\n|\Z)', analysis_summary, re.DOTALL)
        if status_section:
            status_lines = [line for line in status_section.group(1).strip().split('\n') if line.strip() != "No status codes found."]
            for line in status_lines:
                status_match = re.match(r'  (\d{3}): (\d+)', line)
                if status_match:
                    status_code, count = status_match.groups()
                    count = int(count)
                    if status_code.startswith('4') and status_code != '404':
                        if count > 0: suggestions.append(f"- **Client-Side Errors ({status_code}):** Encountered {count} times. These indicate issues with client requests. Analyze affected URLs and referrers to understand why clients are making malformed or unauthorized requests.")
                    elif status_code == '404':
                        if count > 0: suggestions.append(f"- **Not Found Errors ({status_code}):** Detected {count} times. While common, a high volume could indicate broken links on your site, missing content, or malicious scanning. Review these URLs.")
                    elif status_code.startswith('5'):
                        if count > 0: suggestions.append(f"- **Server-Side Failures ({status_code}):** Critical, {count} instances. These require immediate attention. Correlate timestamps with server-side error logs (e.g., application server, database) to pinpoint the exact cause of failure.")
                    elif status_code.startswith('3'):
                        if count > 0: suggestions.append(f"- **Excessive Redirects ({status_code}):** {count} redirects were observed. While redirects are normal, too many can impact performance and SEO. Verify these are intentional and efficient (e.g., using 301 for permanent moves).")

        # Extract requests per hour
        hour_section = re.search(r'🕒 Requests Per Hour \(00-23\):\n(.*?)(?=\n\n|\Z)', analysis_summary, re.DOTALL)
        if hour_section:
            hour_lines = [line for line in hour_section.group(1).strip().split('\n') if line.strip() != "No hourly request data found."]
            hour_data = {}
            for line in hour_lines:
                hour_match = re.match(r'  (\d{2}):00 - (\d+) requests', line)
                if hour_match:
                    hour_data[int(hour_match.group(1))] = int(hour_match.group(2))

            if hour_data:
                total_requests = sum(hour_data.values())
                if total_requests > 0:
                    average_requests_per_hour = total_requests / len(hour_data)
                    # Filter out hours with 0 requests for peak/off-peak calculations
                    active_hours = {h: count for h, count in hour_data.items() if count > 0}
                    if active_hours:
                        peak_hours = [h for h, count in active_hours.items() if count > 1.5 * average_requests_per_hour]
                        off_peak_hours = [h for h, count in active_hours.items() if count < 0.5 * average_requests_per_hour]

                        if peak_hours:
                            suggestions.append(f"- **Identify Peak Usage Hours:** {', '.join(f'{h:02d}:00' for h in sorted(peak_hours))} show significantly higher traffic. Ensure your infrastructure can scale to handle these loads without performance degradation. Consider auto-scaling or dedicated resources during these periods.")
                        if off_peak_hours and len(active_hours) > 1: # Only suggest if there's enough data and some low periods
                            suggestions.append(f"- **Utilize Off-Peak Windows:** {', '.join(f'{h:02d}:00' for h in sorted(off_peak_hours))} are low-traffic periods. Schedule maintenance, backups, and non-critical updates during these times to minimize user impact.")
        if not suggestions or all("- Overall System Health" in s for s in suggestions): # Check if only the default "No major issues" was added
            suggestions.append("- **Overall System Health:** No significant issues were automatically detected based on the provided log summary. This indicates a generally healthy system. Continue regular monitoring and proactive maintenance to ensure ongoing stability and performance.")

        return "\n".join(suggestions) + "\n\n---"


    def show_ai_suggestions(self, suggestions):
        self.suggestion_box.config(state=tk.NORMAL)
        self.suggestion_box.delete("1.0", tk.END)
        for line in suggestions.split('\n'):
            line_stripped = line.strip()
            if not line_stripped:
                self.suggestion_box.insert(tk.END, "\n")
            elif line_stripped.startswith("# "):
                self.suggestion_box.insert(tk.END, line_stripped[2:] + "\n\n", 'title')
            elif line_stripped.startswith("## "):
                self.suggestion_box.insert(tk.END, line_stripped[3:] + "\n", 'heading1')
            elif line_stripped.startswith("### "):
                self.suggestion_box.insert(tk.END, line_stripped[4:] + "\n", 'heading2')
            elif line_stripped.startswith(("- ", "* ")):
                self.suggestion_box.insert(tk.END, "    " + line_stripped[2:] + "\n", 'bullet')
            else:
                self.suggestion_box.insert(tk.END, line_stripped + "\n", 'normal')
        self.suggestion_box.config(state=tk.DISABLED)
        self.export_button.config(state=tk.NORMAL)

    def export_suggestions_to_word(self):
        """Exports the AI suggestions to a .docx Word document."""
        suggestions_text = self.suggestion_box.get("1.0", tk.END).strip()
        if not suggestions_text or "AI Suggestions will appear here" in suggestions_text or "Generating AI suggestions..." in suggestions_text:
            messagebox.showinfo("Export Error", "No AI suggestions to export. Please analyze a log file first.")
            return

        file_path = filedialog.asksaveasfilename(
            defaultextension=".docx",
            filetypes=[("Word Documents", "*.docx")],
            title="Save AI Suggestions Report"
        )

        if not file_path:
            return # User cancelled

        try:
            document = Document()

            # Add a custom style for bullet points if it doesn't exist (ensure it's defined once)
            styles = document.styles
            if 'List Bullet Custom' not in styles:
                bullet_style = styles.add_style('List Bullet Custom', WD_STYLE_TYPE.PARAGRAPH)
                bullet_style.paragraph_format.left_indent = Inches(0.5)
                bullet_style.paragraph_format.first_line_indent = Inches(-0.25)
                bullet_style.font.size = Pt(11)
                # You might need to add a run with a specific font (e.g., Wingdings) for custom bullet glyphs
                # For standard bullets, 'List Bullet' built-in style is usually sufficient.

            lines = suggestions_text.split('\n')
            for line in lines:
                line_stripped = line.strip()
                if not line_stripped:
                    document.add_paragraph() # Add empty paragraph for spacing
                    continue

                if line_stripped.startswith("# "):
                    document.add_heading(line_stripped[2:].strip(), level=0)
                elif line_stripped.startswith("## "):
                    document.add_heading(line_stripped[3:].strip(), level=1)
                elif line_stripped.startswith("### "):
                    document.add_heading(line_stripped[4:].strip(), level=2)
                elif line_stripped.startswith(("- ", "* ")):
                    text_content = line_stripped[2:].strip()
                    document.add_paragraph(text_content, style='List Bullet') # Use built-in 'List Bullet' style
                else:
                    document.add_paragraph(line_stripped)

            document.save(file_path)
            messagebox.showinfo("Export Successful", f"AI suggestions exported to:\n{file_path}")

        except Exception as e:
            messagebox.showerror("Export Error", f"Failed to export to Word: {e}\n\n"
                                   "Please ensure the file is not open in another program and you have write permissions.")


if __name__ == "__main__":
    root = tk.Tk()
    app = LogAnalyzerGUI(root)
    root.mainloop()