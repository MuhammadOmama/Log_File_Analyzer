
def parse_log_line(line):
    if "ERROR" in line:
        return "ERROR"
    elif "INFO" in line:
        return "INFO"
    elif "WARNING" in line:
        return "WARNING"
    else:
        return None
