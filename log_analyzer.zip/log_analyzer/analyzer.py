
import os
from multiprocessing import Pool, cpu_count
from worker import process_chunk

def analyze_log_file_parallel(file_path, num_workers=None):
    if not os.path.exists(file_path):
        raise FileNotFoundError("Log file not found")

    num_workers = num_workers or cpu_count()
    
    # Split the file into chunks
    with open(file_path, 'r') as file:
        lines = file.readlines()

    chunk_size = len(lines) // num_workers
    chunks = [lines[i:i + chunk_size] for i in range(0, len(lines), chunk_size)]

    with Pool(processes=num_workers) as pool:
        results = pool.map(process_chunk, chunks)

    # Combine results
    final_result = {}
    for partial in results:
        for key, value in partial.items():
            final_result[key] = final_result.get(key, 0) + value

    return final_result
